import { NextRequest } from 'next/server'

// OpenAI-compatible streaming proxy
// Connects to any vLLM / Ollama / OpenAI-compatible endpoint
export async function POST(req: NextRequest) {
  const { messages, model } = await req.json()

  const INFERENCE_URL = process.env.INFERENCE_URL || 'http://localhost:11434/v1'
  const API_KEY = process.env.INFERENCE_API_KEY || 'not-needed'

  // Map our model names to actual model IDs on the inference server
  const MODEL_MAP: Record<string, string> = {
    'llama-3-70b': process.env.MODEL_LLAMA || 'llama3:70b',
    'mistral-7b': process.env.MODEL_MISTRAL || 'mistral:7b',
    'qwen-2.5-72b': process.env.MODEL_QWEN || 'qwen2.5:72b',
  }

  const actualModel = MODEL_MAP[model] || model

  try {
    const response = await fetch(`${INFERENCE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        model: actualModel,
        messages: messages.map((m: { role: string; content: string }) => ({
          role: m.role,
          content: m.content,
        })),
        stream: true,
        max_tokens: 2048,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      const err = await response.text()
      return new Response(
        JSON.stringify({ error: `Inference server error: ${response.status}`, details: err }),
        { status: 502, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Stream the response through to the client (SSE passthrough)
    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        if (!reader) {
          controller.close()
          return
        }
        try {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            controller.enqueue(value)
          }
        } catch (e) {
          // Client disconnected or stream error
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })
  } catch (err) {
    return new Response(
      JSON.stringify({
        error: 'Cannot connect to inference server',
        hint: 'Make sure INFERENCE_URL is set in .env.local and the GPU server is running',
      }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }
    )
  }
}
