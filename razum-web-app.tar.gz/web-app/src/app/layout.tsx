import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Razum AI — Свободный AI',
  description: 'ChatGPT за 490 руб. Без VPN. Без цензуры. Оплата картой МИР и СБП.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
