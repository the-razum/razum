import Link from 'next/link'

const plans = [
  {
    name: 'Free',
    price: '0 ₽',
    period: '',
    desc: 'Без регистрации',
    features: ['30 запросов/день', 'Базовые модели', 'Стандартная скорость', 'Веб-интерфейс'],
    cta: 'Начать бесплатно',
    href: '/chat',
    featured: false,
  },
  {
    name: 'Старт',
    price: '490 ₽',
    period: '/мес',
    desc: 'Дешевле чашки кофе',
    features: ['500 запросов/день', 'Все модели', 'Стриминг ответов', 'Мобильное приложение'],
    cta: 'Подключить',
    href: '#',
    featured: false,
  },
  {
    name: 'Базовый',
    price: '990 ₽',
    period: '/мес',
    desc: 'Для ежедневной работы',
    features: ['2 000 запросов/день', 'Горячие ноды', 'Быстрый стриминг', 'Приоритетная поддержка'],
    cta: 'Подключить',
    href: '#',
    featured: true,
  },
  {
    name: 'Про',
    price: '1 990 ₽',
    period: '/мес',
    desc: 'Для разработчиков',
    features: ['Безлимит', 'API + SDK', 'Файнтюнинг моделей', '99.5% SLA'],
    cta: 'Подключить',
    href: '#',
    featured: false,
  },
]

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-bg">
      <nav className="border-b border-border">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold">
            <span className="w-2 h-2 rounded-full bg-accent" />
            Razum AI
          </Link>
          <Link href="/chat" className="text-sm text-accent hover:underline">
            Открыть чат
          </Link>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-3">Простые цены. Платите картой.</h1>
          <p className="text-text2 text-lg">
            Карта МИР, СБП, ЮKassa, Stripe, крипто. Международные цены: $5 / $10 / $20 / $100.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map(plan => (
            <div
              key={plan.name}
              className={`rounded-xl border p-6 flex flex-col ${
                plan.featured
                  ? 'border-accent bg-accent/5 relative'
                  : 'border-border bg-surface'
              }`}
            >
              {plan.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-accent text-bg text-xs font-bold rounded-full">
                  Популярный
                </div>
              )}
              <div className="text-lg font-semibold">{plan.name}</div>
              <div className="mt-2">
                <span className="text-3xl font-bold">{plan.price}</span>
                <span className="text-text2 text-sm">{plan.period}</span>
              </div>
              <div className="text-text2 text-sm mt-1">{plan.desc}</div>
              <ul className="mt-6 space-y-3 flex-1">
                {plan.features.map(f => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <svg className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href={plan.href}
                className={`mt-6 block text-center py-2.5 rounded-lg font-medium text-sm transition ${
                  plan.featured
                    ? 'bg-accent text-bg hover:bg-accent/90'
                    : 'bg-surface2 text-text hover:bg-border'
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center text-text2 text-sm">
          <p>Оплата в RZM-токенах — скидка 20%. Для бизнеса (9 990 ₽/мес) — пишите нам.</p>
        </div>
      </div>
    </div>
  )
}
